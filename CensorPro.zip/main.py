
import cv2
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import numpy as np
import urllib.request
import webbrowser
import os
import json
import pytesseract
import subprocess

pytesseract.pytesseract.tesseract_cmd = r"C:/Program Files/Tesseract-OCR/tesseract.exe"

class VideoMaskApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Masquage Vidéo Complet")
        self.root.geometry("1000x720")

        self.video_path = None
        self.zones = []
        self.zone_confidences = []
        self.scale_ratio = 1.0
        self.blur_type = tk.StringVar(value='Flou')
        self.blur_intensity = tk.IntVar(value=50)

        self.setup_ui()
        self.load_autosave()

    def setup_ui(self):
        self.canvas_frame = tk.Frame(self.root)
        self.canvas_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.controls_frame = tk.Frame(self.root, width=300)
        self.controls_frame.pack(side=tk.RIGHT, fill=tk.Y)
        ttk.Label(self.controls_frame, text="CensorPro v1.0.0", foreground="#888").pack(padx=10, pady=(5, 0))
        ttk.Button(self.controls_frame, text="🔄 Vérifier les mises à jour", command=self.check_for_updates).pack(padx=10, pady=(0, 10), fill="x")

        self.image_panel = tk.Label(self.canvas_frame, bg="black")
        self.image_panel.pack(expand=True)
        self.image_panel.bind("<Button-1>", self.start_selection)
        self.image_panel.bind("<B1-Motion>", self.draw_selection_preview)
        self.image_panel.bind("<ButtonRelease-1>", self.end_selection)

        ttk.Button(self.controls_frame, text="Sélectionner une vidéo", command=self.select_video).pack(pady=10, padx=10, fill="x")
        ttk.Button(self.controls_frame, text="Détecter texte (OCR)", command=self.detect_ocr).pack(pady=5, padx=10, fill="x")

        ttk.Label(self.controls_frame, text="Type de floutage :").pack(padx=10, anchor="w")
        ttk.OptionMenu(self.controls_frame, self.blur_type, "Flou", "Flou", "Pixelisation", "Ovale").pack(padx=10, pady=(0, 5), fill="x")

        ttk.Label(self.controls_frame, text="Intensité du flou :").pack(padx=10, anchor="w")
        ttk.Scale(self.controls_frame, from_=1, to=100, variable=self.blur_intensity,
                  orient="horizontal", command=lambda e: self.display_preview()).pack(padx=10, pady=(0, 10), fill="x")

        ttk.Button(self.controls_frame, text="🎬 Exporter vidéo floutée", command=self.export_masked_video).pack(pady=(5, 5), padx=10, fill="x")
        ttk.Label(self.controls_frame, text="Zones sélectionnées :").pack(padx=10, anchor="w")
        ttk.Label(self.controls_frame, text="Scores de détection (%) :").pack(padx=10, anchor="w")
        self.score_listbox = tk.Listbox(self.controls_frame, height=6)
        self.score_listbox.pack(padx=10, pady=(0, 10), fill="x")
        ttk.Button(self.controls_frame, text="❌ Supprimer zone sélectionnée", command=self.remove_score_zone).pack(padx=10, pady=(0, 10), fill="x")
        self.score_listbox.bind("<<ListboxSelect>>", self.on_score_click)
        self.zone_listbox = tk.Listbox(self.controls_frame)
        self.zone_listbox.pack(padx=10, pady=(0, 10), fill="x")
        self.zone_listbox.bind("<<ListboxSelect>>", self.on_zone_select)
        ttk.Button(self.controls_frame, text="❌ Supprimer la zone sélectionnée", command=self.remove_selected_zone).pack(padx=10, pady=(0, 15), fill="x")
        ttk.Button(self.controls_frame, text="📁 Traitement par lot", command=self.batch_process_videos).pack(pady=(5, 15), padx=10, fill="x")
        ttk.Button(self.controls_frame, text="🔍 Détecter modèle sélectionné", command=self.detect_from_selected_model).pack(padx=10, pady=(0, 10), fill="x")
        ttk.Label(self.controls_frame, text="Seuil de détection (%) :").pack(padx=10, anchor="w")
        ttk.Label(self.controls_frame, text="Plus le seuil est élevé, plus la détection est stricte.").pack(padx=10, anchor="w")
        self.match_threshold = tk.IntVar(value=75)
        ttk.Scale(self.controls_frame, from_=50, to=100, variable=self.match_threshold, orient="horizontal").pack(padx=10, pady=(0, 10), fill="x")

    def select_video(self):
        path = filedialog.askopenfilename(filetypes=[("Vidéos", "*.mp4 *.avi *.mov")])
        if path:
            self.video_path = path
            self.load_first_frame()

    def load_first_frame(self):
        cap = cv2.VideoCapture(self.video_path)
        ret, frame = cap.read()
        cap.release()
        if not ret:
            messagebox.showerror("Erreur", "Impossible de lire la vidéo.")
            return
        self.original_frame = frame
        self.frame = self.resize_image(frame)
        self.display_preview()

    def resize_image(self, frame):
        h, w = frame.shape[:2]
        self.scale_ratio = min(1.0, 700 / w, 650 / h)
        return cv2.resize(frame, (int(w * self.scale_ratio), int(h * self.scale_ratio)))

    def display_preview(self):
        if not hasattr(self, 'frame'):
            return
        preview = self.frame.copy()
        preview = self.apply_blur_effect(preview)
        for idx, (x1, y1, x2, y2) in enumerate(self.zones):
            cv2.rectangle(preview, (x1, y1), (x2, y2), (0, 255, 0), 2)
        img = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(preview, cv2.COLOR_BGR2RGB)))
        self.image_panel.configure(image=img)
        self.image_panel.image = img

    def apply_blur_effect(self, frame):
        intensity = max(1, self.blur_intensity.get())
        for (x1, y1, x2, y2) in self.zones:
            if y2 - y1 <= 0 or x2 - x1 <= 0:
                continue
            roi = frame[y1:y2, x1:x2]
            if roi.size == 0:
                continue
            if self.blur_type.get() == "Pixelisation":
                pixel_size = max(2, 100 // intensity)
                temp = cv2.resize(roi, (pixel_size, pixel_size), interpolation=cv2.INTER_LINEAR)
                roi_blurred = cv2.resize(temp, (x2 - x1, y2 - y1), interpolation=cv2.INTER_NEAREST)
            elif self.blur_type.get() == "Ovale":
                mask = np.zeros_like(roi, dtype=np.uint8)
                center = ((x2 - x1) // 2, (y2 - y1) // 2)
                axes = (max((x2 - x1)//2 - 1, 1), max((y2 - y1)//2 - 1, 1))
                cv2.ellipse(mask, center, axes, 0, 0, 360, (255, 255, 255), -1)
                blurred = cv2.GaussianBlur(roi, (21, 21), 0)
                roi_blurred = np.where(mask == 255, blurred, roi)
            else:
                ksize = max(3, (intensity // 2) * 2 + 1)
                roi_blurred = cv2.GaussianBlur(roi, (ksize, ksize), 0)
            frame[y1:y2, x1:x2] = roi_blurred
        return frame
    def start_selection(self, event):
        self.select_start = (event.x, event.y)

    def draw_selection_preview(self, event):
        if not hasattr(self, 'select_start'):
            return
        temp = self.frame.copy()
        x1, y1 = self.select_start
        x2, y2 = event.x, event.y
        cv2.rectangle(temp, (x1, y1), (x2, y2), (0, 255, 255), 2)
        img = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(temp, cv2.COLOR_BGR2RGB)))
        self.image_panel.configure(image=img)
        self.image_panel.image = img

    def end_selection(self, event):
        if not hasattr(self, 'select_start'):
            return
        x1, y1 = self.select_start
        x2, y2 = event.x, event.y
        x1, x2 = sorted([x1, x2])
        y1, y2 = sorted([y1, y2])
        self.zones.append((x1, y1, x2, y2))
        self.zone_confidences.append(1.0)
        self.display_preview()
        self.save_autosave()

    def detect_ocr(self):
        if not self.video_path:
            return
        cap = cv2.VideoCapture(self.video_path)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        step = max(1, total_frames // 10)
        for i in range(0, min(total_frames, step * 10), step):
            cap.set(cv2.CAP_PROP_POS_FRAMES, i)
            ret, frame = cap.read()
            if not ret:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.equalizeHist(gray)
            data = pytesseract.image_to_data(gray, output_type=pytesseract.Output.DICT)
            for j in range(len(data['text'])):
                text = data['text'][j].strip()
                if text != "":
                    (x, y, w, h) = (data['left'][j], data['top'][j], data['width'][j], data['height'][j])
                    scale = self.scale_ratio
                    self.zones.append((int(x * scale), int(y * scale), int((x + w) * scale), int((y + h) * scale)))
                    self.zone_confidences.append(1.0)
        cap.release()
        self.display_preview()
        self.save_autosave()

    def export_masked_video(self):
        if not self.video_path:
            return
        output_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 Files", "*.mp4")])
        if not output_path:
            return
        cap = cv2.VideoCapture(self.video_path)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        temp_output = "temp_export.mp4"
        out = cv2.VideoWriter(temp_output, fourcc, fps, (width, height))
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            scaled = self.resize_image(frame)
            blurred = self.apply_blur_effect(scaled.copy())
            final_frame = cv2.resize(blurred, (width, height))
            out.write(final_frame)
        cap.release()
        out.release()
        self.merge_audio_with_video(temp_output, output_path)

    def batch_process_videos(self):
        file_paths = filedialog.askopenfilenames(filetypes=[("Vidéos", "*.mp4 *.avi *.mov")])
        if not file_paths:
            return
        output_dir = filedialog.askdirectory(title="Choisir un dossier de sortie")
        if not output_dir:
            return
        for path in file_paths:
            cap = cv2.VideoCapture(path)
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            name = os.path.splitext(os.path.basename(path))[0]
            temp_output = os.path.join(output_dir, f"{name}_TEMP.mp4")
            final_output = os.path.join(output_dir, f"{name}_floute.mp4")
            out = cv2.VideoWriter(temp_output, cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                scaled = self.resize_image(frame)
                blurred = self.apply_blur_effect(scaled.copy())
                full_size = cv2.resize(blurred, (width, height))
                out.write(full_size)
            cap.release()
            out.release()
            self.video_path = path
            self.merge_audio_with_video(temp_output, final_output)

    def merge_audio_with_video(self, video_output, final_output):
        if not self.video_path:
            return
        try:
            temp_audio = "temp_audio.aac"
            extract_cmd = ["ffmpeg", "-y", "-i", self.video_path, "-vn", "-acodec", "copy", temp_audio]
            subprocess.run(extract_cmd, check=True)
            merge_cmd = ["ffmpeg", "-y", "-i", video_output, "-i", temp_audio, "-c:v", "copy", "-c:a", "aac", "-strict", "experimental", final_output]
            subprocess.run(merge_cmd, check=True)
            os.remove(temp_audio)
            os.remove(video_output)
            messagebox.showinfo("Export", f"Vidéo exportée avec audio :\n{final_output}")
        except Exception as e:
            messagebox.showerror("Erreur", f"Échec de l'intégration audio : {e}")

    def save_autosave(self):
        try:
            project_data = {
                "zones": self.zones,
                "confidences": self.zone_confidences,
                "blur_type": self.blur_type.get(),
                "blur_intensity": self.blur_intensity.get()
            }
            with open("autosave.json", "w", encoding="utf-8") as f:
                json.dump(project_data, f)
        except Exception as e:
            print("Erreur de sauvegarde automatique :", e)

    def load_autosave(self):
        try:
            if os.path.exists("autosave.json"):
                with open("autosave.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.zones = data.get("zones", [])
                    self.zone_confidences = data.get("confidences", [])
                    self.blur_type.set(data.get("blur_type", "Flou"))
                    self.blur_intensity.set(data.get("blur_intensity", 50))
        except Exception as e:
            print("Erreur de chargement auto :", e)


    def refresh_zone_dropdown(self):
        self.zone_listbox.delete(0, tk.END)
        for i, (x1, y1, x2, y2) in enumerate(self.zones):
            self.zone_listbox.insert(tk.END, f"Zone {i+1}: ({x1},{y1}) → ({x2},{y2})")

    def remove_selected_zone(self):
        selection = self.zone_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        if 0 <= idx < len(self.zones):
            del self.zones[idx]
            del self.zone_confidences[idx]
            self.refresh_zone_dropdown()
            self.display_preview()
            self.save_autosave()

    def on_zone_select(self, event):
        pass  # À compléter si besoin pour focus ou highlight plus tard

    def detect_from_selected_model(self):
        if not self.video_path or not self.zones:
            messagebox.showwarning("Modèle", "Veuillez sélectionner une zone manuellement d'abord.")
            return
        model_zone = self.zones[-1]  # dernière zone ajoutée
        x1, y1, x2, y2 = model_zone
        model_crop = self.frame[y1:y2, x1:x2]
        if model_crop.size == 0:
            messagebox.showwarning("Modèle", "Zone sélectionnée invalide.")
            return

        cap = cv2.VideoCapture(self.video_path)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        step = max(1, total_frames // 10)
        matched = []

        for i in [0, total_frames // 4, total_frames // 2]:
            cap.set(cv2.CAP_PROP_POS_FRAMES, i)
            ret, frame = cap.read()
            if not ret:
                continue
            resized = self.resize_image(frame)
            res = cv2.matchTemplate(resized, model_crop, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            threshold = self.match_threshold.get() / 100
            if max_val >= threshold:
                h, w = model_crop.shape[:2]
                top_left = max_loc
                x1, y1 = top_left
                x2, y2 = x1 + w, y1 + h
                self.zones.append((x1, y1, x2, y2))
                self.zone_confidences.append(round(max_val, 2))
                matched.append((round(max_val * 100), (x1, y1, x2, y2)))

        cap.release()
        if matched:
            self.display_preview()
            self.refresh_zone_dropdown()
            msg = "\n".join([f"{score}% : {zone}" for score, zone in matched])
            self.score_listbox.delete(0, tk.END)
            for score, zone in matched:
                self.score_listbox.insert(tk.END, f"{score}% : {zone}")
            messagebox.showinfo("Détection par modèle", f"Zones détectées :\n{msg}")
        else:
            messagebox.showinfo("Détection par modèle", "Aucune zone similaire trouvée.")

    def on_score_click(self, event):
        selection = self.score_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        if 0 <= idx < len(self.zones):
            preview = self.frame.copy()
            preview = self.apply_blur_effect(preview)
            x1, y1, x2, y2 = self.zones[idx]
            cv2.rectangle(preview, (x1, y1), (x2, y2), (0, 0, 255), 3)  # rouge pour surbrillance
            img = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(preview, cv2.COLOR_BGR2RGB)))
            self.image_panel.configure(image=img)
            self.image_panel.image = img

    def remove_score_zone(self):
        selection = self.score_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        if 0 <= idx < len(self.zones):
            del self.zones[idx]
            del self.zone_confidences[idx]
            self.refresh_zone_dropdown()
            self.score_listbox.delete(idx)
            self.display_preview()
            self.save_autosave()

    def check_for_updates(self):
        try:
            current_version = "v1.0.0"
            url = "https://raw.githubusercontent.com/the-lord-en/CensorPro/main/version.txt"
            with urllib.request.urlopen(url) as response:
                latest = response.read().decode().strip()
                if latest != current_version:
                    if messagebox.askyesno("Mise à jour disponible", f"Nouvelle version {latest} disponible. Ouvrir la page de téléchargement ?"):
                        webbrowser.open("https://github.com/the-lord-en/CensorPro/releases/latest")
                else:
                    messagebox.showinfo("CensorPro", "Aucune mise à jour disponible.")
        except Exception as e:
            messagebox.showerror("Erreur de mise à jour", str(e))
if __name__ == "__main__":
    root = tk.Tk()
    app = VideoMaskApp(root)
    root.mainloop()